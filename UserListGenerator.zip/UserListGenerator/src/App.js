//Created by Michael


import React, { useState } from "react";
import FakeUserForm from "./FakeUserForm.js";
import GetFakeUserList from "./GetFakeUserList.js";


export default function App() {
  const [userArr, setUserArr] = useState([]);
  const [userNumber, setUserNumber] = useState(10);
  const [dataLocation, setDataLocation] = useState("");
  const [saveData, setSaveData] = useState("");



  return(
  <>
  <FakeUserForm
    userArr={userArr}
    setUserArr={setUserArr}
    userNumber={userNumber}
    setUserNumber={setUserNumber}
    dataLocation={dataLocation}
    setDataLocation={setDataLocation}
    saveData={saveData}
    setSaveData={setSaveData}
  />
  <GetFakeUserList
    userArr={userArr}
    setUserArr={setUserArr}
    userNumber={userNumber}
    setUserNumber={setUserNumber}
    dataLocation={dataLocation}
    setDataLocation={setDataLocation}
    saveData={saveData}
    setSaveData={setSaveData}
  />
  </>
);
}
