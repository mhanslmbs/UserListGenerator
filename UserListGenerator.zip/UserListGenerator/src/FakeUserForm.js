//Created by Michael
//Input form

import React, {useEffect,useState} from "react";
import {
  sortAscending,
  sortDecending,
  filterTitle,
  clearSave
} from "./AppFunction.js"
import "./App.css";

export default function FakeUserForm({
  userArr,
  setUserArr,
  userNumber,
  setUserNumber,
  dataLocation,
  setDataLocation,
  saveData,
  setSaveData
}){

  const [inputNumber, setInputNumber] = useState(userNumber);

  useEffect(() => {
      document.addEventListener("keydown", function (event: any) {
        if (event.keyCode === 13 && event.target.nodeName === "INPUT") {
          var form = event.target.form;
          var index = Array.prototype.indexOf.call(form, event.target);
          form.elements[index + 1].focus();
          event.preventDefault();
        }
      });
    }, []);

  return(
    <form>
      <h2>User List</h2>
      <div className="userForm">
        {"Number of Users: "}
        <input
          type="text"
          value={inputNumber}
          className="userNumber"
          onChange={event => setInputNumber(event.target.value)}
          onBlur={event => setUserNumber(event.target.value)}
        />
        <span>{dataLocation}</span>
        <button
          onClick={event => clearSave(setUserArr,event,setInputNumber)}
        >Clear Local Storage
        </button>
        <br/>
        <label htmlFor="ascending">Sort by Ascending</label>
        <input
          type="radio"
          name="orderRadio"
          id="ascending"
          value="ascending"
          onChange={() => sortAscending(setSaveData,setUserArr,userArr)}
        />
        <span>
        <label htmlFor="decending">Sort by Decending</label>
        </span>
        <input
          type="radio"
          name="orderRadio"
          id="decending"
          value="decending"
          onChange={() => sortDecending(setSaveData,setUserArr,userArr)}
        />
        <br/>
        <label htmlFor="filterTitle">Filter by: </label>
        <select
        name="filterTitle"
        onChange={event => filterTitle(setSaveData,setUserArr,userNumber,event.target.value)}
        >
        <option value="all">All</option>
        <option value="Mr">Mr</option>
        <option value="Mrs">Mrs</option>
        <option value="Ms">Ms</option>
        <option value="Miss">Miss</option>
       </select>
      </div>
    </form>
  )
}
