//Created by Michael
//Input form

import React from "react";
import {
  sortAscending,
  sortDecending,
  filterTitle,
  clearSave
} from "./AppFunction.js"
import "./App.css";

export default function FakeUserForm({
  userArr,
  setUserArr,
  userNumber,
  setUserNumber,
  dataLocation,
  setDataLocation,
  saveData,
  setSaveData
}){

  function keydown(e){//HTML Enter　
    if(e.keyCode === 13){//Enter 0x0D
      var obj = document.activeElement;
      obj.nextElementSibling.focus();
    }
  }
  window.onkeydown = keydown;

  return(
    <>
      <h2>User List</h2>
      <div className="userForm">
        {"Number of Users: "}
        <input
          type="text"
          defaultValue={userNumber}
          className="userNumber"
          onBlur={event => setUserNumber(event.target.value)}
        />
        <span>{dataLocation}</span>
        <button
          onClick={() => clearSave(setUserArr)}
        >Clear Local Storage
        </button>
        <br/>
        <label htmlFor="ascending">Sort by Ascending</label>
        <input
          type="radio"
          name="orderRadio"
          id="ascending"
          value="ascending"
          onChange={() => sortAscending(setSaveData,setUserArr,userArr)}
        />
        <span>
        <label htmlFor="decending">Sort by Decending</label>
        </span>
        <input
          type="radio"
          name="orderRadio"
          id="decending"
          value="decending"
          onChange={() => sortDecending(setSaveData,setUserArr,userArr)}
        />
        <br/>
        <label htmlFor="filterTitle">Filter by: </label>
        <select
        name="filterTitle"
        onChange={event => filterTitle(setSaveData,setUserArr,userNumber,event.target.value)}
        >
        <option value="all">All</option>
        <option value="Mr">Mr</option>
        <option value="Mrs">Mrs</option>
        <option value="Ms">Ms</option>
        <option value="Miss">Miss</option>
       </select>
      </div>
    </>
  )
}
