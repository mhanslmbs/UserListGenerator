//Created by Michael
//Create user list

import React, {useEffect } from "react";
import {
  loadJSON,
  saveJSON,
  getFakePerson1,
  titleColor,
} from "./AppFunction.js";
import "./App.css";

export default function GetFakeUserList({
  userArr,
  setUserArr,
  userNumber,
  setUserNumber,
  dataLocation,
  setDataLocation,
  saveData,
  setSaveData
}){

//save data to local storage
  useEffect(() => {
    if (userArr.length===0) return;
    if (saveData === "save"){
    saveJSON(`userNumber:${userNumber}`,userArr);
  }
  },[userArr]);

// Get data from API or local storage
  useEffect(() => {
    if(userNumber >0){
      let tmpdata = loadJSON(`userNumber:${userNumber}`);
        if(!tmpdata){
        getFakePerson1(userNumber,setUserArr);
        setDataLocation("(From: Server via API)");
        setSaveData("save")
        }
      else{
          setUserArr(tmpdata);
          setDataLocation("(From: Local Storage)")

      }
    }
    else {
      setUserArr([]);
    }


  },[userNumber]);

return(
  <>
    <ul>
    {userArr.map((item,i)=>(
      <li key={i} style={{color:titleColor(item.name.title)}} >
      <img src={item.picture.medium} alt={item.name.last} />
      {item.name.title} {item.name.first} {item.name.last} - {item.email}
      </li>
    ))}
    </ul>
  </>
)
}
