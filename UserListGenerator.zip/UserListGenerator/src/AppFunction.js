//Created by Michael
//Common functions

import React, { useState, useEffect } from "react";
export const loadJSON=key=>key&& JSON.parse(localStorage.getItem(key));
export const saveJSON=(key,data)=>localStorage.setItem(key,JSON.stringify(data));


//Method 1
export const getFakePerson1 = (userNumber,myFun)=>{
    fetch(`https://api.randomuser.me/?nat=US&results=${userNumber}`)
    .then(res=>res.json())
    .then(json=>json.results)
    .then(myFun)
    .catch(console.error);
  }

//Method 2
export const getFakePerson2 = async(userNumber,myFun) => {
  try{
    const res = await fetch(`https://api.randomuser.me/?nat=US&results=${userNumber}`);
    const { results } = await res.json();
    console.log(results);
    myFun(results);
  }catch (error){
    console.error(error);
  }
};

//Method 3
export const getFakePerson3=count=>
  new Promise((resolves,rejects)=>{
    const api=`https://api.randomuser.me/?nat=US&results=${count}`;
    const request=new XMLHttpRequest();
    request.open("GET",api);
    request.onload=()=>
    request.status===200
      ? resolves(JSON.parse(request.response).results)
      : rejects(Error(request.statusText));
    request.onerror=err=>rejects(err);
    request.send();
    }
  )
//Change color by title
export const titleColor = (title)=>{
  if (title === "Mr"){
    return(
      "red"
    )
  }
  else if (title === "Ms"){
    return(
      "blue"
    )
  }
  else if (title === "Mrs"){
    return(
      "green"
    )
  }
  else if (title === "Miss"){
    return(
      "Yellow"
    )
  }
};

// sort last name by ascending alphabetical order
export const sortAscending = (setSave,setUser,arr)=>{
    setSave("false");
    setUser([
      ...arr.sort((a, b) => a.name.last.localeCompare(b.name.last))
    ]);
  };
// sort last name by decending alphabetical order
export const sortDecending = (setSave,setUser,arr)=>{
    setSave("false");
    setUser([
      ...arr.sort((b, a) => a.name.last.localeCompare(b.name.last))
    ]);
  };

// filter by title
export const filterTitle = (setSave,setUser,userNumber,ttl) => {
    let tmpdata = loadJSON(`userNumber:${userNumber}`);
    setSave("false");
    if(ttl === "all"){
        setUser(tmpdata);
    }
    else{
    setUser(tmpdata.filter(user => user.name.title=== ttl));
    }
  }

// clear local storage
  export const clearSave = (f1) => {
    if (window.confirm('Clear data from local storage?')){
      localStorage.clear();
      f1([]);
    }

    }
