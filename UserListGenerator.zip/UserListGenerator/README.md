Requirements:
Node (v14.18.1)+

Preperation Steps:

1. Open cmd and change to project directory
2. Run "npm install"
3. Run "npm run build"
4. Run "npm start"
5. Open (http://localhost:3000) to view it in your browser.

Features:

- List users from https://api.randomuser.me via API
- Input number in "Number of Users" to display new user list.
- The user list will automatically save to local storage.
- The application will automatically load the saved list,
  otherwise it will get a new list from API.
- Click "Clear Local Storage" to clear all saved data.
- Click the radio button to sort alphabetically by the user's last name.
- Select a title from the "Filter by" dropdown menu to filter the list by the user's title.


